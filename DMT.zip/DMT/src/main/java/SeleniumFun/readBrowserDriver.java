package SeleniumFun;

public class readBrowserDriver{

	public void readbrowser() {
}
}